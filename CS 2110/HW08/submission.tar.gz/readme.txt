This is a maze game where you try to collect the blue squares and avoid the red ones, while getting to the green finish line. 

If you hit the red square you lose. 
If you collect the blue square you gain a point. 
You cannot go out of bounds. 

Hit the backspace key to return to the menu at anytime. 
Hit the enter key at the Start screen and Game Over Screen to start the game. 
Use the arrow keys to move around. 


 