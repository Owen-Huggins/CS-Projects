/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x10 character Character.png
 * Time-stamp: Monday 04/04/2022, 17:20:46
 *
 * Image Information
 * -----------------
 * Character.png 30@10
 *
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CHARACTER_H
#define CHARACTER_H

extern const unsigned short character[300];
#define CHARACTER_SIZE 600
#define CHARACTER_LENGTH 300
#define CHARACTER_WIDTH 30
#define CHARACTER_HEIGHT 10

#endif
