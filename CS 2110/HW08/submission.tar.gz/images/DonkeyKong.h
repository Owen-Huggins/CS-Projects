/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x37 DK DK.png
 * Time-stamp: Tuesday 04/05/2022, 01:33:28
 *
 * Image Information
 * -----------------
 * DK.png 50@37
 *
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DonkeyKong_H
#define DonkeyKong_H

extern const unsigned short DonkeyKong[1850];
#define DK_SIZE 3700
#define DK_LENGTH 1850
#define DK_WIDTH 50
#define DK_HEIGHT 37

#endif
